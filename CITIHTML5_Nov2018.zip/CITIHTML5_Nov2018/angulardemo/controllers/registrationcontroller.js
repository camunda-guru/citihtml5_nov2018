homeApp.controller('RegistrationController',['$scope',function($scope)
{
//model
    $scope.user={
        firstName:'',
        lastName:'',
        dob:'',
        address:'',
        country:'',
        email:'',
        gender:'',
        profilePhoto:''
    }

    //function
    $scope.save=function()
    {
        console.log($scope.user);
    }


}])