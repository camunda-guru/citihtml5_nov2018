homeApp.controller('HomeController',['$scope',function($scope)
{
    //user model
    $scope.userObj={
        firstName:"Anand",
        lastName:"Kumar"
    }



}]);