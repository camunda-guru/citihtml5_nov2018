window.addEventListener('load',function()
{
   // alert("Window loaded");

    var reg=document.getElementById("register");

    reg.addEventListener('click',function()
    {
        window.open("register.html",'registration',
            'width=600, height=400,left=200,top=100');

    })
})
